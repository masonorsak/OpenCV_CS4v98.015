import numpy as np
import cv2

#this is the cascade we just made. Call what you want
tennis_cascade = cv2.CascadeClassifier('TennisBallHaarCascade.xml')

#cap = cv2.VideoCapture(0)
cap = cv2.imread('tennisball.jpg')
cap1 = cv2.imread('pos/1.jpg')
cap2 = cv2.imread('tennisball2.jpg')
cap3 = cv2.imread('tennisball3.jpg')
cap4 = cv2.imread('tennisball4.jpg')

#while 1:
#ret, img = cap.read()
gray = cv2.cvtColor(cap, cv2.COLOR_BGR2GRAY)
gray1 = cv2.cvtColor(cap1, cv2.COLOR_BGR2GRAY)
gray2 = cv2.cvtColor(cap2, cv2.COLOR_BGR2GRAY)
gray3 = cv2.cvtColor(cap3, cv2.COLOR_BGR2GRAY)
gray4 = cv2.cvtColor(cap4, cv2.COLOR_BGR2GRAY)
tennis = tennis_cascade.detectMultiScale(gray, 2, 2)
tennis1 = tennis_cascade.detectMultiScale(gray1, 2, 2)
tennis2 = tennis_cascade.detectMultiScale(gray2, 2, 2)
tennis3 = tennis_cascade.detectMultiScale(gray3, 2, 2)
tennis4 = tennis_cascade.detectMultiScale(gray4, 2, 2)

# add this
for (x,y,w,h) in tennis:
    cv2.rectangle(cap,(x,y),(x+w,y+h),(255,255,0),2)
for (x,y,w,h) in tennis1:
    cv2.rectangle(cap1,(x,y),(x+w,y+h),(255,255,0),2)
for (x,y,w,h) in tennis2:
    cv2.rectangle(cap2,(x,y),(x+w,y+h),(255,255,0),2)
for (x,y,w,h) in tennis3:
    cv2.rectangle(cap3,(x,y),(x+w,y+h),(255,255,0),2)
for (x,y,w,h) in tennis4:
    cv2.rectangle(cap4,(x,y),(x+w,y+h),(255,255,0),2)

cv2.imshow('img',cap)
cv2.imshow('img1',cap1)
cv2.imshow('img2',cap2)
cv2.imshow('img3',cap3)
cv2.imshow('img4',cap4)
#k = cv2.waitKey(30) & 0xff
#if k == 27:
#    break

#cap.release()
cv2.waitKey(0)
cv2.destroyAllWindows()