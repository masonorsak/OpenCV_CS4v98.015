import PIL
import os
import os.path
from PIL import Image, ImageOps

f = r'C:/Users/Mason/Desktop/UTD Spring 2021/Undergrad Research - 4V98.015/Face Haar/tmp'
for file in os.listdir(f):
    f_img = f+"/"+file
    img = Image.open(f_img)
    img = ImageOps.grayscale(img) 
    img = img.resize((100,100))
    img.save(f_img)